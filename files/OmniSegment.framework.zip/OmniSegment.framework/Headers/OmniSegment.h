//
//  OmniSegment.h
//  OmniSegment
//
//  Created by Eason on 2020/4/6.
//  Copyright © 2020 Eason. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for OmniSegment.
FOUNDATION_EXPORT double OmniSegmentVersionNumber;

//! Project version string for OmniSegment.
FOUNDATION_EXPORT const unsigned char OmniSegmentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OmniSegment/PublicHeader.h>


